// download jquery here: http://jquery.com

$(document).ready(function() {
  
  
  $("p").click(function() {
    $("p").css("color", "green");
    // $(this).css("color", "green");
  });
  
});