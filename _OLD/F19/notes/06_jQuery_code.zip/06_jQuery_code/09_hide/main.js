$(document).ready(function() {
  
  
  $("#myButton").click(function() {
    $("p").hide();
    // $("p").fadeOut();
  });
  
});