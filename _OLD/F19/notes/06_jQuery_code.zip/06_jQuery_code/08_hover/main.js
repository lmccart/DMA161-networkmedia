$(document).ready(function() {
  
  
  $("p").hover(function() {
    $("p").css("color", "green");
    // $(this).css("color", "green");
  });
  
});