$(document).ready(function() {
  
  // var elements = $("p");
  // var elements = $(".banana");
  // var elements = $("#third");
  console.log(elements);
});