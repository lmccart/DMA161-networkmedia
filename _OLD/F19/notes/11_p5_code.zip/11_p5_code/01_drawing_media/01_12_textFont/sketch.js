function setup() {
  createCanvas(600, 600);
  textSize(40);
  textFont("Times");
}

function draw() {
  text("hello world", 100, 100);
}