function setup() {
  createCanvas(600, 600);
}

function draw() {
  text("hello world", 100, 100);
}