$(document).ready(function() {
  
  
  $("#myButton").click(function() {
    $("p").css("color", "green");
    $("img").attr("src", "http://vacationpassage.com/wp-content/gallery/clementon-park/WhitewaterFusion.jpg");
  });
  
});