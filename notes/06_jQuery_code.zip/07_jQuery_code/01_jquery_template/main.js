$(document).ready(function() {
  
  // put javascript code here
  console.log("page has loaded!");
  
  
});
