$(document).ready(function() {
  
  // get an attribute
  var src = $("#myPic").attr("src");
  console.log(src);
  
  
  // or set a css properties
  $("#myPic").attr("src", "http://4.bp.blogspot.com/-L7f1jZFLmSw/UjlcQsPcxmI/AAAAAAAAHkY/xTmvuOl7VjM/s1600/3.jpg")
  
});