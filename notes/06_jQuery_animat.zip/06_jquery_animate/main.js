$(document).ready(function() {
  
//  $("#myText").animate({left: 300, top: 500}, 3000, "linear");
  
  
  
  $("#myText").animate({
    left: 300,
    top: 500,
    fontSize: 60
  }, 3000, "linear");
  
  
});
